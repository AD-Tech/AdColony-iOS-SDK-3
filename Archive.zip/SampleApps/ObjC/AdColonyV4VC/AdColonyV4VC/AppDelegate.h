//
//  AppDelegate.h
//  AdColonyV4VC
//
//  Created by Owain Moss on 3/18/16.
//  Copyright (c) 2016 AdColony. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@end
