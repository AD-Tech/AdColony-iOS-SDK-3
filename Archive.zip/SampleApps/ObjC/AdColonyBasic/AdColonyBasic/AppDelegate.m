//
//  AppDelegate.m
//  AdColonyBasic
//
//  Created by Owain Moss on 5/18/16.
//  Copyright (c) 2016 AdColony. All rights reserved.
//

#import "AppDelegate.h"

#import <AdColony/AdColony.h>

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    return YES;
}
@end
