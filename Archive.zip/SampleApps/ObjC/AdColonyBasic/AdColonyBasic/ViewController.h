//
//  ViewController.h
//  AdColonyBasic
//
//  Created by Owain Moss on 1/13/15.
//  Copyright (c) 2016 AdColony. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *background;
@end
